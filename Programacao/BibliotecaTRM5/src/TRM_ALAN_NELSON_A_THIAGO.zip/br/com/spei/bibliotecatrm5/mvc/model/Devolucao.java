package br.com.spei.bibliotecatrm5.mvc.model;

public class Devolucao {
	
	private int codDevolucao;
	private Usuario usuario;
	
	public int getCodDevolucao() {
		return codDevolucao;
	}
	public void setCodDevolucao(int codDevolucao) {
		this.codDevolucao = codDevolucao;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
}
