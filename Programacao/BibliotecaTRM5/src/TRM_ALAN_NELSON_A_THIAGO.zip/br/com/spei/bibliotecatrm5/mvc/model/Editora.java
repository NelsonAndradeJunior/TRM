package br.com.spei.bibliotecatrm5.mvc.model;

public class Editora {

	private int codEditora;
	private String nomeEditora;
	
	public int getCodEditora() {
		return codEditora;
	}
	public void setCodEditora(int codEditora) {
		this.codEditora = codEditora;
	}
	public String getNomeEditora() {
		return nomeEditora;
	}
	public void setNomeEditora(String nomeEditora) {
		this.nomeEditora = nomeEditora;
	}
}
