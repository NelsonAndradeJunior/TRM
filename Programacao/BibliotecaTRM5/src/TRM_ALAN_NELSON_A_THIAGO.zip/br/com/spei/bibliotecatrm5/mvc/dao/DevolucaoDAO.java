package br.com.spei.bibliotecatrm5.mvc.dao;

import java.util.List;

import br.com.spei.bibliotecatrm5.mvc.model.Devolucao;

public interface DevolucaoDAO {
	
	public List<Devolucao> listAll();
	

}
