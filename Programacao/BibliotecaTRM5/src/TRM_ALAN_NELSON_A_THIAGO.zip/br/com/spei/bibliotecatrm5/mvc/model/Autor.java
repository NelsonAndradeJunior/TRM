package br.com.spei.bibliotecatrm5.mvc.model;

public class Autor {
	private int codAutor;
	private String nomeAutor;
	
	public int getCodAutor() {
		return codAutor;
	}
	public void setCodAutor(int codAutor) {
		this.codAutor = codAutor;
	}
	public String getNomeAutor() {
		return nomeAutor;
	}
	public void setNomeAutor(String nomeAutor) {
		this.nomeAutor = nomeAutor;
	}
}
